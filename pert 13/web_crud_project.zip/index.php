<h1>CRUD Produk & Kategori</h1>
<ul>
    <li><a href="kategori/index.php">Kelola Kategori</a></li>
    <li><a href="produk/index.php">Kelola Produk</a></li>
</ul>
