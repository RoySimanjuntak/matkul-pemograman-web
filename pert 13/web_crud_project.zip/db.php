<?php
$conn = mysqli_connect("localhost", "root", "", "web_crud");
?>