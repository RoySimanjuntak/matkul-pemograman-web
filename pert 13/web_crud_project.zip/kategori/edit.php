<?php
include '../db.php';
$id = $_GET['id'];
$query = mysqli_query($conn, "SELECT * FROM kategori WHERE id_kategori=$id");
$row = mysqli_fetch_assoc($query);
if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    mysqli_query($conn, "UPDATE kategori SET nama_kategori='$nama' WHERE id_kategori=$id");
    header('Location: index.php');
}
?>
<form method="post">
    <input type="text" name="nama" value="<?= $row['nama_kategori'] ?>" required>
    <button type="submit" name="submit">Update</button>
</form>
