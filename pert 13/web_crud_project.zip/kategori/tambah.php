<?php
include '../db.php';
if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    mysqli_query($conn, "INSERT INTO kategori(nama_kategori) VALUES ('$nama')");
    header('Location: index.php');
}
?>
<form method="post">
    <input type="text" name="nama" placeholder="Nama Kategori" required>
    <button type="submit" name="submit">Tambah</button>
</form>
