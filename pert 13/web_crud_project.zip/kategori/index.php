<?php
include '../db.php';
$result = mysqli_query($conn, "SELECT * FROM kategori");
?>
<h2>Daftar Kategori</h2>
<a href="tambah.php">Tambah Kategori</a>
<table border="1">
<tr><th>ID</th><th>Nama</th><th>Aksi</th></tr>
<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
<td><?= $row['id_kategori'] ?></td>
<td><?= $row['nama_kategori'] ?></td>
<td>
    <a href="edit.php?id=<?= $row['id_kategori'] ?>">Edit</a> |
    <a href="hapus.php?id=<?= $row['id_kategori'] ?>">Hapus</a>
</td>
</tr>
<?php } ?>
</table>
