<?php
include '../db.php';
$id = $_GET['id'];
$query = mysqli_query($conn, "SELECT * FROM produk WHERE id_produk=$id");
$row = mysqli_fetch_assoc($query);
$kategori = mysqli_query($conn, "SELECT * FROM kategori");
if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $id_kategori = $_POST['id_kategori'];
    mysqli_query($conn, "UPDATE produk SET nama_produk='$nama', id_kategori=$id_kategori WHERE id_produk=$id");
    header('Location: index.php');
}
?>
<form method="post">
    <input type="text" name="nama" value="<?= $row['nama_produk'] ?>" required>
    <select name="id_kategori" required>
        <?php while($kat = mysqli_fetch_assoc($kategori)) { ?>
        <option value="<?= $kat['id_kategori'] ?>" <?= ($kat['id_kategori'] == $row['id_kategori']) ? 'selected' : '' ?>><?= $kat['nama_kategori'] ?></option>
        <?php } ?>
    </select>
    <button type="submit" name="submit">Update</button>
</form>
