<?php
include '../db.php';
$kategori = mysqli_query($conn, "SELECT * FROM kategori");
if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $id_kategori = $_POST['id_kategori'];
    mysqli_query($conn, "INSERT INTO produk(nama_produk, id_kategori) VALUES ('$nama', $id_kategori)");
    header('Location: index.php');
}
?>
<form method="post">
    <input type="text" name="nama" placeholder="Nama Produk" required>
    <select name="id_kategori" required>
        <option value="">Pilih Kategori</option>
        <?php while($row = mysqli_fetch_assoc($kategori)) { ?>
        <option value="<?= $row['id_kategori'] ?>"><?= $row['nama_kategori'] ?></option>
        <?php } ?>
    </select>
    <button type="submit" name="submit">Tambah</button>
</form>
