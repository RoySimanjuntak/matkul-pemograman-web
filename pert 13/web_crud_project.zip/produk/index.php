<?php
include '../db.php';
$result = mysqli_query($conn, "SELECT produk.*, kategori.nama_kategori FROM produk JOIN kategori ON produk.id_kategori = kategori.id_kategori");
?>
<h2>Daftar Produk</h2>
<a href="tambah.php">Tambah Produk</a>
<table border="1">
<tr><th>ID</th><th>Nama Produk</th><th>Kategori</th><th>Aksi</th></tr>
<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
<td><?= $row['id_produk'] ?></td>
<td><?= $row['nama_produk'] ?></td>
<td><?= $row['nama_kategori'] ?></td>
<td>
    <a href="edit.php?id=<?= $row['id_produk'] ?>">Edit</a> |
    <a href="hapus.php?id=<?= $row['id_produk'] ?>">Hapus</a>
</td>
</tr>
<?php } ?>
</table>
